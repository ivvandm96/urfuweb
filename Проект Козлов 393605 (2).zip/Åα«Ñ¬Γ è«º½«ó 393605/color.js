function color()
{
document.getElementById("out_col").append("Кнопка меняет цвет при изменении разрешения!");

}