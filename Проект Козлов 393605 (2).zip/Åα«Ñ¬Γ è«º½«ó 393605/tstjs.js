function tstjs()
{
document.getElementById("out_rez").append("Сейчас вам необходимо заполнить форму на сайте!");

}